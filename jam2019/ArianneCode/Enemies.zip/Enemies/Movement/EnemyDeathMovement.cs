﻿using UnityEngine;
using System.Collections;

namespace PlatformerPro
{
	/// <summary>
	/// Enemy death movement.
	/// </summary>
	public abstract class EnemyDeathMovement : EnemyMovement
	{

	}
}